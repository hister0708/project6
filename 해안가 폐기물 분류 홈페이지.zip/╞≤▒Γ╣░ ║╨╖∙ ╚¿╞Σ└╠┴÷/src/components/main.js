import React from 'react';
import { Link } from 'react-router-dom';
// import imgUrl2 from "../임시이미지.jpg";
import imgUrl3 from "../미래융합교육원.png";
import imgUrl4 from "../프로젝트이미지.png";
import '../App.css'; // CSS 파일을 임포트
import SmallNotice from './smallnotice'; // 공지사항 리스트 컴포넌트 임포트
import SmallBoard from './smallboard'; // 게시판 리스트 컴포넌트 임포트

function Main() {
  return (
    <div className="main-container">
      <div className="main-content">
        <div className="right-column">
          <div className="center-container">
            <img src={imgUrl4} style={{ width: '1000px', height: 'auto' }} alt="임시이미지" />
          </div>
          <div className="info-container">
            {/* 공지사항과 게시판을 묶는 div */}
            <div className="info-box">
              <div className="info-box-header">
                <h5>공지사항</h5>
                <Link to="/notices" className="more-button">더보기</Link> {/* 더보기 버튼 추가 */}
              </div>
              <div className="info-box-content">
                <SmallNotice apiEndpoint="http://localhost:8080/api/notices?limit=5" />
              </div>
            </div>
            <div className="info-box">
              <div className="info-box-header">
                <h5>게시판</h5>
                <Link to="/posts" className="more-button">더보기</Link> {/* 더보기 버튼 추가 */}
              </div>
              <div className="info-box-content">
                <SmallBoard apiEndpoint="http://localhost:8080/api/posts/latest" />
              </div>
            </div>
          </div>
          <div className="button-container">
            <Link to="/quiz" className="circle-button">퀴즈</Link>
            <Link to="/classification" className="circle-button">분류하기</Link>
            <Link to="/posts" className="circle-button">자유게시판</Link>
          </div>
        </div>
      </div>
      <div className="center-container">
        1조 DNA <img src={imgUrl3} style={{ width: '200px', height: 'auto' }} alt="미래융합교육원" />
      </div>
    </div>
  );
}

export default Main;
