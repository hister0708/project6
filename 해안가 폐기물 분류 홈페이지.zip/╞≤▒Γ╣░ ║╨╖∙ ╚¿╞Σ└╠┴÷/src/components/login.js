import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post("http://localhost:8000/api/login/", {
        username,
        password
      });

      // 서버 응답에서 토큰과 사용자 이름을 가져옵니다.
      const { token, username: responseUsername } = response.data;

      if (token && responseUsername) {
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify({ username: responseUsername }));
        alert('로그인 성공!');
        navigate('/main'); // 로그인 후 /main으로 이동
      } else {
        setError('로그인 응답에 사용자 이름이 포함되어 있지 않습니다.');
      }
    } catch (error) {
      if (error.response) {
        setError('서버 응답 오류');
        console.error('Response Error:', error.response.data);
      } else if (error.request) {
        setError('요청 오류');
        console.error('Request Error:', error.request);
      } else {
        setError('오류 발생');
        console.error('Error Message:', error.message);
      }
    }
  };

  return (
    <div className="center-container">
      <div className="login-container" style={{ margin: 100 }}>
        <h2>로그인</h2>
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="username">아이디</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">비밀번호</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <div className="error">{error}</div>}
          <div className="form-actions">
            <button type="submit">로그인</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Login;