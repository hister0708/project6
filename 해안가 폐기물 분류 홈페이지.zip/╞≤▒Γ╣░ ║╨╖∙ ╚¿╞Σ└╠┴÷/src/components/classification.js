
import React, { useState } from 'react';
import axios from 'axios';
import '../App.css'; // CSS 파일 import
import { useAuth } from './AuthContext'; // AuthContext import

function ImageUploader() {
  const [selectedImage, setSelectedImage] = useState(null);
  const [selectedModel, setSelectedModel] = useState('');
  const [prediction, setPrediction] = useState('');
  const [points, setPoints] = useState(0);
  const [error, setError] = useState('');
  const { user } = useAuth(); // AuthContext에서 사용자 정보 가져오기

  const handleImageChange = (event) => {
    setSelectedImage(event.target.files[0]);
  };

  const handleModelChange = (event) => {
    setSelectedModel(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // 사용자 로그인을 확인
    if (!user) {
      setError('로그인 후 업로드할 수 있습니다.');
      return;
    }

    // 필수 입력값 확인
    if (!selectedImage) {
      setError('이미지를 선택해 주세요.');
      return;
    }

    if (!selectedModel) {
      setError('모델을 선택해 주세요.');
      return;
    }

    setError(''); // 모든 필드가 올바르게 입력된 경우 오류 메시지 초기화

    const formData = new FormData();
    formData.append('image', selectedImage);
    formData.append('keras_models', selectedModel);

    try {
      const response = await axios.post('http://localhost:8000/api/image_classifier/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Token ${localStorage.getItem('token')}` // 템플릿 리터럴 수정
        }
      });

      if (response.data.result) {
        setPrediction(response.data.result);
        if (response.data.points) {
          setPoints(response.data.points); // 포인트 지급 확인 및 상태 업데이트
        }
      }
    } catch (error) {
      console.error('Error:', error);
      setError('이미지 업로드 중 오류가 발생했습니다.');
    }
  };

  return (
    <div className="image-uploader-container">
      <h1>Upload Image</h1>
      {user ? (
        <form onSubmit={handleSubmit} className="image-uploader-form">
          <input type="file" onChange={handleImageChange} />
          <select onChange={handleModelChange} value={selectedModel}>
            {/* 모델 선택 목록 예시 */}
            <option value="">모델을 선택하세요</option>
            <option value="1_haeyang.keras">해양모델(로프, 어망)</option>
            <option value="2_glass.keras">유리병모델(갈색병, 흰색병, 녹색병)</option>
            <option value="3_can.keras">캔모델(스팸캔, 통조림캔)</option>
          </select>
          <button type="submit">Upload</button>
          {error && <div className="error">{error}</div>}
        </form>
      ) : (
        <p>로그인 후 이미지를 업로드할 수 있습니다.</p>
      )}

      <div className="image-uploader-results">
        {prediction && <p>분류 결과: {prediction}</p>}
        {points > 0 && <p>획득 포인트: {points}</p>}
      </div>
    </div>
  );
}

export default ImageUploader;
