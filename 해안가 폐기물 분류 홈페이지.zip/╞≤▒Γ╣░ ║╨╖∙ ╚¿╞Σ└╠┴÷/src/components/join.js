import React, { useState } from "react";
import axios from 'axios'; // axios를 사용하여 API 요청

function Join() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // API 요청
      const response = await axios.post('http://localhost:8000/api/register/', {
        username: username,
        password: password,
        email: email,
      });

      // 성공 메시지와 함께 메인 페이지로 이동
      window.alert('회원가입이 성공적으로 완료되었습니다!');
      window.location.href = '/main'; // 메인 페이지로 리다이렉트
    } catch (error) {
      // 에러 처리
      console.error('Error response:', error.response); // 서버 응답 확인
      setError('회원가입 중 오류가 발생했습니다.');
    }
  };

  return (
    <div className="center-container">
      <div className="join-container" style={{ margin: 100 }}>
        <h2>회원가입</h2>
        <form onSubmit={handleSubmit} className="join-form">
          <div className="form-group">
            <label htmlFor="username">사용자 ID</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">비밀번호</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">이메일</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          {error && <div className="error">{error}</div>}
          <button type="submit">회원가입</button>
        </form>
      </div>
    </div>
  );
}

export default Join;
