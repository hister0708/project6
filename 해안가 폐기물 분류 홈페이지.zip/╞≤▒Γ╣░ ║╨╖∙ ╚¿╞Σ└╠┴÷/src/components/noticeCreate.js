import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function NoticeCreate() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isImportant, setIsImportant] = useState(false); // 중요 여부
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const user = JSON.parse(localStorage.getItem('user')); // 사용자 정보 가져오기
    if (!user) {
      setError('로그인 후 작성할 수 있습니다.');
      return;
    }

    try {
      await axios.post('http://localhost:8080/api/notices', {
        userId: user.username, // 사용자 ID 설정
        noticeTitle: title,
        noticeContent: content,
        isImportant,
      });

      alert('공지사항이 작성되었습니다.');
      navigate('/notices'); // 공지사항 목록으로 이동
    } catch (error) {
      setError('공지사항 작성 중 오류가 발생했습니다.');
      console.error('Error:', error);
    }
  };

  return (
    <div className="center-container">
      <div className="notice-create-container">
        <h2>공지사항 작성</h2>
        <form onSubmit={handleSubmit} className="notice-create-form">
          <div className="form-group">
            <label htmlFor="title">제목</label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="content">내용</label>
            <textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
            />
          </div>
          <div className="checkbox-group">
            <input
              type="checkbox"
              id="isImportant"
              checked={isImportant}
              onChange={(e) => setIsImportant(e.target.checked)}
            />
            <label htmlFor="isImportant">중요</label>
          </div>
          {error && <div className="error">{error}</div>}
          <div className="form-actions">
            <button type="submit">공지사항 작성</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default NoticeCreate;
