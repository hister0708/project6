import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function CreatePost() {
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      setError('로그인 후 작성할 수 있습니다.');
      return;
    }

    try {
      await axios.post('http://localhost:8080/api/posts', {
        userId: user.username, // 로컬 스토리지에서 사용자 ID 가져오기
        postTitle,
        postContent,
      });

      alert('게시글이 작성되었습니다.');
      navigate('/posts'); // 게시글 목록으로 이동
    } catch (error) {
      setError('게시글 작성 중 오류가 발생했습니다.');
      console.error('Error:', error);
    }
  };

  return (
    <div className="center-container">
      <div className="create-post-container">
        <h2>게시글 작성</h2>
        <form onSubmit={handleSubmit} className="create-post-form">
          <div className="form-group">
            <label htmlFor="postTitle">제목</label>
            <input
              type="text"
              id="postTitle"
              value={postTitle}
              onChange={(e) => setPostTitle(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="postContent">내용</label>
            <textarea
              id="postContent"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              required
            />
          </div>
          {error && <div className="error">{error}</div>}
          <div className="form-actions">
            <button type="submit">게시글 작성</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default CreatePost;
