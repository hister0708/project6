import React, { useEffect, useState } from "react";
import axios from "axios";

function UserProfile() {
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get("http://localhost:8000/api/user/", {
          headers: {
            Authorization: `Token ${token}`
          }
        });
        setUser(response.data);
      } catch (error) {
        if (error.response) {
          setError('서버 응답 오류');
          console.error('Response Error:', error.response.data);
        } else if (error.request) {
          setError('요청 오류');
          console.error('Request Error:', error.request);
        } else {
          setError('오류 발생');
          console.error('Error Message:', error.message);
        }
      }
    };

    fetchUserData();
  }, []);

  return (
    <div>
      {error && <div className="error">{error}</div>}
      {user ? (
        <div>
          <h2>사용자 정보</h2>
          <p>아이디: {user.username}</p>  {/* 이메일 제외 */}
        </div>
      ) : (
        <p>사용자 정보를 불러오는 중...</p>
      )}
    </div>
  );
}

export default UserProfile;
