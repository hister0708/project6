import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Quiz() {
  const [question, setQuestion] = useState(null);
  const [result, setResult] = useState('');
  const token = localStorage.getItem('token'); // 로컬 스토리지에서 토큰을 가져옵니다.

  useEffect(() => {
    const fetchQuestion = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/quiz/', {
          headers: {
            'Authorization': `Token ${token}`  // 인증 토큰을 헤더에 추가
          }
        });
        setQuestion(response.data);
      } catch (error) {
        console.error('문제를 가져오는 중 오류가 발생했습니다.', error.response ? error.response.data : error.message);
        if (error.response && error.response.status === 401) {
          window.location.href = '/login'; // 로그인 페이지 URL로 리디렉션
        } else if (error.response && error.response.status === 403) {
          console.log('접근 권한이 없습니다.');
        } else {
          console.log('문제를 가져오는 중 오류가 발생했습니다.');
        }
      }
    };
    fetchQuestion();
  }, [token]);

  const handleChoiceClick = async (choice) => {
    try {
      const response = await axios.post('http://localhost:8000/api/quiz/', {
        answer: choice
      }, {
        headers: {
          'Authorization': `Token ${token}`  // 인증 토큰을 헤더에 추가
        }
      });

      if (response.data.correct) {
        setResult('정답입니다! 포인트를 지급합니다!');
      } else {
        setResult('오답입니다.');
      }

      setTimeout(() => {
        window.location.href = '/main';  // '/main'으로 리디렉션
      }, 2000);  // 2초 후 리디렉션

    } catch (error) {
      console.error('정답을 확인하는 중 오류가 발생했습니다.', error.response ? error.response.data : error.message);
    }
  };

  return (
    <div className="quiz-container">
      {question ? (
        <div>
          <h2>{question.question}</h2>
          <div>
            <button onClick={() => handleChoiceClick('O')}>O</button>
            <button onClick={() => handleChoiceClick('X')}>X</button>
          </div>
          {result && <div className="result-message">{result}</div>}
        </div>
      ) : (
        <div>{result || '문제를 불러오는 중입니다...'}</div>
      )}
    </div>
  );
}

export default Quiz;
