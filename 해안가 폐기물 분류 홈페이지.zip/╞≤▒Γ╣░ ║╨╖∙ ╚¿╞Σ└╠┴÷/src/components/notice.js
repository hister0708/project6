import React, { useState, useEffect } from "react";
import axios from 'axios'; // 공지사항 목록을 가져오기 위한 axios
import { Link } from 'react-router-dom'; // 페이지 이동을 위한 Link 컴포넌트
import { useAuth } from "./AuthContext"; // AuthContext 사용

function NoticeList() {
  const { user } = useAuth(); // 로그인 상태 가져오기
  const [notices, setNotices] = useState([]); // 공지사항 목록 상태
  const [loading, setLoading] = useState(true); // 데이터 로딩 상태
  const [error, setError] = useState(''); // 에러 상태
  const [showImportant, setShowImportant] = useState(false); // 중요 공지사항 필터링

  useEffect(() => {
    // 공지사항 목록을 가져오는 함수
    const fetchNotices = async () => {
      try {
        const url = showImportant ? 'http://localhost:8080/api/notices/important' : 'http://localhost:8080/api/notices';
        const response = await axios.get(url);
        setNotices(response.data); // 서버에서 받은 공지사항 목록 상태에 저장
      } catch (error) {
        setError('공지사항을 가져오는 중 오류가 발생했습니다.');
      } finally {
        setLoading(false); // 데이터 로딩 완료
      }
    };

    fetchNotices();
  }, [showImportant]); // 중요 공지사항 필터링 상태가 변경될 때마다 호출

  return (
    <div className="center-container">
      <div className="notice-list-container">
        <h2>공지사항</h2>
        {/* 중요 공지사항 필터링 버튼 */}
        <button onClick={() => setShowImportant(!showImportant)}>
          {showImportant ? '모든 공지사항 보기' : '중요 공지사항만 보기'}
        </button>
        {/* 로그인한 사용자만 공지사항 작성 버튼을 볼 수 있도록 조건부 렌더링 */}
        {user && (
          <a href="/notices/create" className="create-notice-button">
            공지사항 작성
          </a>
        )}
        {/* 공지사항 목록 또는 로딩 상태 표시 */}
        {loading ? (
          <p>로딩 중...</p>
        ) : notices.length === 0 ? (
          <p className="no-notices">공지사항이 없습니다</p>
        ) : (
          <table className="notice-table">
            <thead>
              <tr>
                <th>제목</th>
                <th>작성자</th>
                <th>작성일</th>
              </tr>
            </thead>
            <tbody>
              {notices.map((notice) => (
                <tr key={notice.noticeId}>
                  <td>
                    <Link to={`/notices/${notice.noticeId}`}>
                      {notice.noticeTitle}
                    </Link>
                  </td>
                  <td>{notice.userId}</td> {/* 작성자 ID 표시 */}
                  <td>{new Date(notice.createAt).toLocaleDateString()}</td> {/* 작성일 표시 */}
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {error && <div className="error">{error}</div>}
      </div>
    </div>
  );
}

export default NoticeList;
