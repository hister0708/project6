import React, { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const response = await axios.get('http://localhost:8000/api/user/', {
            headers: { Authorization: `Token ${token}` },
          });
          const userData = response.data;
          setUser(userData);

          // 로컬 스토리지에 사용자 정보 저장 (숫자로 저장)
          localStorage.setItem('is_superuser', userData.is_superuser ? '1' : '0');
        } catch (error) {
          console.error('사용자 정보 로드 오류:', error.response ? error.response.data : error.message);
          localStorage.removeItem('token');
          localStorage.removeItem('is_superuser');
          setUser(null);
        }
      } else {
        setUser(null);
      }
    };

    checkAuth();
  }, []);

  const login = async (username, password) => {
    try {
      const response = await axios.post('http://localhost:8000/api/login/', { username, password });
      const { token } = response.data;
      localStorage.setItem('token', token);

      const userResponse = await axios.get('http://localhost:8000/api/user/', {
        headers: { Authorization: `Token ${token}` },
      });

      const userData = userResponse.data;
      setUser(userData);

      // 로컬 스토리지에 사용자 정보 저장 (숫자로 저장)
      localStorage.setItem('is_superuser', userData.is_superuser ? '1' : '0');

      navigate('/main');
    } catch (error) {
      console.error('로그인 오류:', error.response ? error.response.data : error.message);
    }
  };

  const logout = async () => {
    try {
      const token = localStorage.getItem('token');
      if (token) {
        await axios.post('http://localhost:8000/api/logout/', {}, {
          headers: { Authorization: `Token ${token}` },
        });
      }
      localStorage.removeItem('token');
      localStorage.removeItem('is_superuser');
      setUser(null);
      navigate('/login');
    } catch (error) {
      console.error('로그아웃 오류:', error.response ? error.response.data : error.message);
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
