import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function SmallNotice({ title, apiEndpoint }) {
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true); // 로딩 상태 추가
  const [error, setError] = useState(''); // 오류 상태 추가

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get(apiEndpoint);
        // 최신 5개 항목을 가져온다고 가정
        let latestNotices = response.data;
        // 최신 게시물이 맨 위로 오도록 정렬
        latestNotices = latestNotices.sort((a, b) => new Date(b.createAt) - new Date(a.createAt)).slice(0, 5);
        setNotices(latestNotices);
      } catch (error) {
        console.error("공지사항을 가져오는 중 오류가 발생했습니다.", error);
        setError('공지사항을 가져오는 중 오류가 발생했습니다.'); // 오류 상태 업데이트
      } finally {
        setLoading(false); // 로딩 완료
      }
    };

    fetchNotices();
  }, [apiEndpoint]);

  if (loading) return <p>로딩 중...</p>; // 로딩 중 메시지
  if (error) return <p>{error}</p>; // 오류 메시지

  return (
    <div className="notice-list-preview-container">
      <h2>{title}</h2>
      <ul className="notice-list-preview">
        {notices.length > 0 ? (
          notices.map(notice => (
            <li key={notice.noticeId}> {/* 각 항목에 유일한 key 설정 */}
              <Link to={`/notices/${notice.noticeId}`}>{notice.noticeTitle}</Link>
            </li>
          ))
        ) : (
          <li className="empty-message">공지사항이 없습니다.</li>
        )}
      </ul>
    </div>
  );
}

export default SmallNotice;
