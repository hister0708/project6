// src/components/BoardList.js
import React, { useState, useEffect } from "react";
import axios from 'axios'; // 게시글 목록을 가져오기 위한 axios
import { useAuth } from "./AuthContext"; // AuthContext 사용
import { Link } from 'react-router-dom'; // 페이지 이동을 위한 Link 컴포넌트

function PostList() {
  const { user } = useAuth(); // 로그인 상태 가져오기
  const [posts, setPosts] = useState([]); // 게시글 목록 상태
  const [loading, setLoading] = useState(true); // 데이터 로딩 상태
  const [error, setError] = useState(''); // 에러 상태

  useEffect(() => {
    // 게시글 목록을 가져오는 함수
    const fetchPosts = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/posts');
        setPosts(response.data); // 서버에서 받은 게시글 목록 상태에 저장
      } catch (error) {
        setError('게시글 목록을 가져오는 중 오류가 발생했습니다.');
      } finally {
        setLoading(false); // 데이터 로딩 완료
      }
    };

    fetchPosts();
  }, []);

  return (
    <div className="center-container">
      <div className="board-list-container">
        <h2>게시글 목록</h2>
        {/* 로그인한 사용자만 버튼을 볼 수 있도록 조건부 렌더링 */}
        {user && (
          <a href="/board/create" className="create-post-button">
            게시글 작성
          </a>
        )}
        {/* 게시글 목록 또는 로딩 상태 표시 */}
        {loading ? (
          <p>로딩 중...</p>
        ) : posts.length === 0 ? (
          <p className="no-posts">글이 없습니다</p>
        ) : (
          <table className="board-table">
            <thead>
              <tr>
                <th>제목</th>
                <th>작성자</th>
                <th>작성일</th>
              </tr>
            </thead>
            <tbody>
              {posts.map((post) => (
                <tr key={post.postId}>
                  <td>
                    <Link to={`/posts/${post.postId}`}>{post.postTitle}</Link>
                  </td>
                  <td>{post.userId}</td> {/* 작성자 이름 표시 */}
                  <td>{new Date(post.createAt).toLocaleDateString()}</td> {/* 작성일 표시 */}
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {error && <div className="error">{error}</div>}
      </div>
    </div>
  );
}

export default PostList;
