import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import '../App.css'; // CSS 파일 import

function PostDetail() {
  const { postId } = useParams(); // URL에서 postId 추출
  const [post, setPost] = useState(null); // 게시글 상태
  const [comments, setComments] = useState([]); // 댓글 상태
  const [newComment, setNewComment] = useState(''); // 새 댓글 입력값
  const [loading, setLoading] = useState(true); // 로딩 상태
  const [error, setError] = useState(''); // 오류 메시지 상태
  const [currentUser, setCurrentUser] = useState(null); // 현재 사용자 정보 상태
  const [isEditing, setIsEditing] = useState(false); // 게시글 수정 모드
  const [editedPostTitle, setEditedPostTitle] = useState('');
  const [editedPostContent, setEditedPostContent] = useState('');
  const [editCommentId, setEditCommentId] = useState(null); // 댓글 수정 중인 ID
  const [editedCommentContent, setEditedCommentContent] = useState('');
  const navigate = useNavigate(); // useNavigate 훅을 사용하여 navigate 함수 정의

  // 컴포넌트가 마운트될 때 게시글과 댓글 데이터를 가져오는 useEffect 훅
  useEffect(() => {
    const fetchPostDetails = async () => {
      try {
        // 로컬 스토리지에서 사용자 정보 가져오기
        const user = JSON.parse(localStorage.getItem('user'));
        setCurrentUser(user); // 현재 사용자 정보 상태 업데이트

        // 게시글 데이터 가져오기
        const postResponse = await axios.get(`http://localhost:8080/api/posts/${postId}`);
        console.log('Post data:', postResponse.data); // 데이터 확인
        setPost(postResponse.data);
        setEditedPostTitle(postResponse.data.postTitle); // 수정 모드 초기화
        setEditedPostContent(postResponse.data.postContent);

        // 댓글 데이터 가져오기
        const commentsResponse = await axios.get(`http://localhost:8080/api/comments/post/${postId}`);
        console.log('Comments data:', commentsResponse.data); // 데이터 확인
        const data = Array.isArray(commentsResponse.data) ? commentsResponse.data : [];
        setComments(data);
      } catch (error) {
        setError('게시글 및 댓글을 가져오는 중 오류가 발생했습니다.'); // 오류 처리
      } finally {
        setLoading(false); // 로딩 완료
      }
    };

    fetchPostDetails();
  }, [postId]);

  // 댓글 추가 처리 함수
  const handleAddComment = async () => {
    if (!currentUser) {
      setError('사용자 정보를 찾을 수 없습니다.');
      return;
    }

    const commentData = {
      userId: currentUser.username, // 사용자 ID 사용 (username으로 설정됨)
      commentContent: newComment,
      postId: postId // 게시글 ID 설정
    };

    try {
      // 댓글 추가 API 호출
      const response = await axios.post('http://localhost:8080/api/comments', commentData);
      setComments([...comments, response.data]); // 새 댓글 추가
      setNewComment(''); // 입력값 초기화
    } catch (error) {
      setError('댓글 추가 중 오류가 발생했습니다.'); // 오류 처리
    }
  };

  // 게시글 수정 처리 함수
  const handleEditPost = async () => {
    if (!currentUser || post.userId !== currentUser.username) {
      setError('게시글 수정 권한이 없습니다.');
      return;
    }

    const updatedPost = {
      ...post,
      postTitle: editedPostTitle,
      postContent: editedPostContent
    };

    try {
      const response = await axios.put(`http://localhost:8080/api/posts/${postId}`, updatedPost);
      setPost(response.data); // 수정된 게시글 데이터로 상태 업데이트
      setIsEditing(false); // 수정 모드 종료
    } catch (error) {
      setError('게시글 수정 중 오류가 발생했습니다.'); // 오류 처리
    }
  };

  // 게시글 삭제 처리 함수
  const handleDeletePost = async () => {
    if (!currentUser || post.userId !== currentUser.username) {
      setError('게시글 삭제 권한이 없습니다.');
      return;
    }

    try {
      await axios.delete(`http://localhost:8080/api/posts/${postId}`);
      navigate('/posts'); // 삭제 후 게시글 목록 페이지로 이동
    } catch (error) {
      setError('게시글 삭제 중 오류가 발생했습니다.'); // 오류 처리
    }
  };

  // 댓글 수정 처리 함수
  const handleEditComment = async (commentId) => {
    if (!currentUser) {
      setError('사용자 정보를 찾을 수 없습니다.');
      return;
    }
  
    const commentToEdit = comments.find(comment => comment.commentId === commentId);
    if (!commentToEdit || commentToEdit.userId !== currentUser.username) {
      setError('댓글 수정 권한이 없습니다.');
      return;
    }
  
    const updatedComment = {
      commentContent: editedCommentContent,
      userId: currentUser.username // Add userId to the request
    };
  
    try {
      const response = await axios.put(`http://localhost:8080/api/comments/${commentId}`, updatedComment);
      setComments(comments.map(comment =>
        comment.commentId === commentId ? response.data : comment
      ));
      setEditCommentId(null);
    } catch (error) {
      setError('댓글 수정 중 오류가 발생했습니다.');
    }
  };

  // 댓글 삭제 처리 함수
  const handleDeleteComment = async (commentId) => {
    if (!currentUser) {
      setError('사용자 정보를 찾을 수 없습니다.');
      return;
    }

    const commentToDelete = comments.find(comment => comment.commentId === commentId);
    if (!commentToDelete || commentToDelete.userId !== currentUser.username) {
      setError('댓글 삭제 권한이 없습니다.');
      return;
    }

    try {
      await axios.delete(`http://localhost:8080/api/comments/${commentId}`);
      setComments(comments.filter(comment => comment.commentId !== commentId)); // 삭제된 댓글 제거
    } catch (error) {
      setError('댓글 삭제 중 오류가 발생했습니다.'); // 오류 처리
    }
  };

  // 게시글 목록으로 돌아가기 함수
  const handleGoToPostList = () => {
    navigate('/posts'); // 게시글 목록 페이지로 이동
  };

  if (loading) return <p>로딩 중...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="board-detail-container">
      {post && (
        <div>
          <div className="board-detail-header">
            {isEditing ? (
              <div>
                <input
                  type="text"
                  value={editedPostTitle}
                  onChange={(e) => setEditedPostTitle(e.target.value)}
                />
                <textarea
                  value={editedPostContent}
                  onChange={(e) => setEditedPostContent(e.target.value)}
                />
                <button onClick={handleEditPost}>저장</button>
                <button onClick={() => setIsEditing(false)}>취소</button>
              </div>
            ) : (
              <div>
                <h2 className="board-detail-title">{post.postTitle}</h2>
                {post.userId === currentUser?.username && (
                  <>
                    <button onClick={() => setIsEditing(true)}>게시글 수정</button>
                    <button onClick={handleDeletePost}>게시글 삭제</button>
                  </>
                )}
              </div>
            )}
          </div>
          <div className="board-detail-content">
            <p>{post.postContent}</p>
          </div>
          <div className="board-detail-meta">
            <p>작성자: {post.userId || '작성자 정보 없음'}</p> {/* 게시글 작성자의 이름 표시 */}
            <p className="board-detail-date">작성일: {new Date(post.createAt).toLocaleDateString()}</p>
            {post.updateAt && <p className="board-detail-date">수정일: {new Date(post.updateAt).toLocaleDateString()}</p>}
          </div>
          <div className="add-comment-section">
            <h3>댓글 추가</h3>
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="댓글을 입력하세요"
            />
            <button onClick={handleAddComment}>댓글 추가</button>
          </div>
          <div className="comments-section">
            <h3>댓글</h3>
            {comments.length > 0 ? (
              comments.map((comment) => (
                <div key={comment.commentId} className="comment">
                  {editCommentId === comment.commentId ? (
                    <div>
                      <textarea
                        value={editedCommentContent}
                        onChange={(e) => setEditedCommentContent(e.target.value)}
                      />
                      <button onClick={() => handleEditComment(comment.commentId)}>저장</button>
                      <button onClick={() => setEditCommentId(null)}>취소</button>
                    </div>
                  ) : (
                    <div>
                      <p>{comment.commentContent}</p>
                      <p>작성자: {comment.userId || '작성자 정보 없음'}</p>
                      {comment.userId === currentUser?.username && (
                        <>
                          <button onClick={() => { setEditCommentId(comment.commentId); setEditedCommentContent(comment.commentContent); }}>수정</button>
                          <button onClick={() => handleDeleteComment(comment.commentId)}>삭제</button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p>댓글이 없습니다.</p>
            )}
          </div>
          <button onClick={handleGoToPostList}>목록으로 돌아가기</button>
        </div>
      )}
    </div>
  );
}

export default PostDetail;
