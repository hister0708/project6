import React, { useContext } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const Logout = () => {
  const { logout } = useAuth();

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:8000/api/logout/', {
        refresh_token: localStorage.getItem('refresh_token') // 저장된 refresh_token을 서버로 보냅니다.
      });
      logout(); // 클라이언트 측 상태 업데이트
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return <button onClick={handleLogout}>Logout</button>;
};

export default Logout;