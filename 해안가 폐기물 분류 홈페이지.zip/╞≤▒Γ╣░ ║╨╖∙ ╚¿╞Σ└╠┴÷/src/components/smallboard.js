import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function SmallBoard({ title, apiEndpoint }) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true); // 로딩 상태 추가
  const [error, setError] = useState(''); // 오류 상태 추가

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await axios.get(apiEndpoint);
        // 최신 5개 게시글을 가져온다고 가정
        const latestPosts = response.data; // 최신 게시글 5개가 이미 필터링되어 있다고 가정
        setPosts(latestPosts);
      } catch (error) {
        console.error("게시글을 가져오는 중 오류가 발생했습니다.", error);
        setError('게시글을 가져오는 중 오류가 발생했습니다.'); // 오류 상태 업데이트
      } finally {
        setLoading(false); // 로딩 완료
      }
    };

    fetchPosts();
  }, [apiEndpoint]);

  if (loading) return <p>로딩 중...</p>; // 로딩 중 메시지
  if (error) return <p>{error}</p>; // 오류 메시지

  return (
    <div className="board-list-preview-container">
      <h2>{title}</h2>
      <ul className="board-list-preview">
        {posts.length > 0 ? (
          posts.map(post => (
            <li key={post.postId}>
              <Link to={`/posts/${post.postId}`}>{post.postTitle}</Link>
            </li>
          ))
        ) : (
          <li className="empty-message">게시글이 없습니다.</li>
        )}
      </ul>
    </div>
  );
}

export default SmallBoard;
