import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import '../App.css'; // CSS 파일 import

function NoticeDetail() {
  const { id } = useParams(); // URL에서 notice ID 추출
  const [notice, setNotice] = useState(null); // 공지사항 상태
  const [isEditing, setIsEditing] = useState(false); // 수정 모드 상태
  const [editedNoticeTitle, setEditedNoticeTitle] = useState('');
  const [editedNoticeContent, setEditedNoticeContent] = useState('');
  const [loading, setLoading] = useState(true); // 로딩 상태
  const [error, setError] = useState(''); // 오류 메시지 상태
  const [currentUser, setCurrentUser] = useState(null); // 현재 사용자 정보 상태
  const navigate = useNavigate(); // useNavigate 훅을 사용하여 navigate 함수 정의

  // 컴포넌트가 마운트될 때 공지사항 데이터 가져오는 useEffect 훅
  useEffect(() => {
    const fetchNoticeDetails = async () => {
      try {
        // 로컬 스토리지에서 사용자 정보 가져오기
        const user = JSON.parse(localStorage.getItem('user'));
        setCurrentUser(user); // 현재 사용자 정보 상태 업데이트

        // 공지사항 데이터 가져오기
        const noticeResponse = await axios.get(`http://localhost:8080/api/notices/${id}`);
        console.log('Notice data:', noticeResponse.data); // 데이터 확인
        setNotice(noticeResponse.data);
        setEditedNoticeTitle(noticeResponse.data.noticeTitle); // 수정 모드 초기화
        setEditedNoticeContent(noticeResponse.data.noticeContent);
      } catch (error) {
        setError('공지사항을 가져오는 중 오류가 발생했습니다.'); // 오류 처리
      } finally {
        setLoading(false); // 로딩 완료
      }
    };

    fetchNoticeDetails();
  }, [id]);

  // 공지사항 수정 처리 함수
  const handleEditNotice = async () => {
    if (!currentUser || notice.userId !== currentUser.username) {
      setError('공지사항 수정 권한이 없습니다.');
      return;
    }

    const updatedNotice = {
      ...notice,
      noticeTitle: editedNoticeTitle,
      noticeContent: editedNoticeContent
    };

    try {
      const response = await axios.put(`http://localhost:8080/api/notices/${id}`, updatedNotice);
      setNotice(response.data); // 수정된 공지사항 데이터로 상태 업데이트
      setIsEditing(false); // 수정 모드 종료
    } catch (error) {
      setError('공지사항 수정 중 오류가 발생했습니다.'); // 오류 처리
    }
  };

  // 공지사항 삭제 처리 함수
  const handleDeleteNotice = async () => {
    if (!currentUser || notice.userId !== currentUser.username) {
      setError('공지사항 삭제 권한이 없습니다.');
      return;
    }

    try {
      await axios.delete(`http://localhost:8080/api/notices/${id}`);
      navigate('/notices'); // 삭제 후 공지사항 목록 페이지로 이동
    } catch (error) {
      setError('공지사항 삭제 중 오류가 발생했습니다.'); // 오류 처리
    }
  };

  // 게시글 목록으로 돌아가기 함수
  const handleGoToNoticeList = () => {
    navigate('/notices'); // 공지사항 목록 페이지로 이동
  };

  if (loading) return <p>로딩 중...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="notice-detail-container">
      {notice && (
        <div>
          <div className="notice-detail-header">
            {isEditing ? (
              <div>
                <input
                  type="text"
                  value={editedNoticeTitle}
                  onChange={(e) => setEditedNoticeTitle(e.target.value)}
                />
                <textarea
                  value={editedNoticeContent}
                  onChange={(e) => setEditedNoticeContent(e.target.value)}
                />
                <button onClick={handleEditNotice}>저장</button>
                <button onClick={() => setIsEditing(false)}>취소</button>
              </div>
            ) : (
              <div>
                <h2 className="notice-detail-title">{notice.noticeTitle}</h2>
                {notice.userId === currentUser?.username && (
                  <>
                    <button onClick={() => setIsEditing(true)}>공지사항 수정</button>
                    <button onClick={handleDeleteNotice}>공지사항 삭제</button>
                  </>
                )}
              </div>
            )}
          </div>
          <div className="notice-detail-content">
            <p>{notice.noticeContent}</p>
          </div>
          <div className="notice-detail-meta">
            <p>작성자: {notice.userId || '작성자 정보 없음'}</p>
            <p className="notice-detail-date">작성일: {new Date(notice.createAt).toLocaleDateString()}</p>
            {notice.updateAt && <p className="notice-detail-date">수정일: {new Date(notice.updateAt).toLocaleDateString()}</p>}
          </div>
          <button onClick={handleGoToNoticeList}>목록으로 돌아가기</button>
        </div>
      )}
    </div>
  );
}

export default NoticeDetail;
