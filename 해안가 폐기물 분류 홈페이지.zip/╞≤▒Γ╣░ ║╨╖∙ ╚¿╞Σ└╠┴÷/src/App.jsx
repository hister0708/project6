// src/App.js
import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './App.css';
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { AuthProvider, useAuth } from "./components/AuthContext";
import Main from "./components/main";
import Login from "./components/login";
import Join from "./components/join";
import PostList from "./components/PostsList";
import NoticeList from "./components/notice";
import NoticeCreate from "./components/noticeCreate";
import NoticeDetail from "./components/noticeDetail";
import Quiz from "./components/quiz";
import PostDetail from "./components/PostDetail.js";
import CreatePost from "./components/CreatePost";
import ImageUploader from "./components/classification";


import imgUrl from "./프로젝트로고3.png";

// 네비게이션 바 컴포넌트
const Navigation = () => {
  const { user } = useAuth(); // 로그인 상태 가져오기

  return (
    <nav className="navbar navbar-expand navbar-dark custom-navbar">
      <div className="container">
        <Link to="/main" className="navbar-brand">
          <img src={imgUrl} style={{ width: '160px', height: 'auto' }} alt="임시로고" />
        </Link>
        <div className="navbar-nav">
          <div className="nav-item dropdown">
            <Link to="/notices" className="nav-link">공지사항</Link>
          </div>
          <div className="nav-item dropdown">
            <Link to="#" className="nav-link dropdown-toggle">분류모델</Link>
            <div className="dropdown-menu">
              <Link to="/classification" className="dropdown-item">분류</Link>
            </div>
          </div>
          <div className="nav-item dropdown">
            <Link to="#" className="nav-link dropdown-toggle">게시판</Link>
            <div className="dropdown-menu">
              <Link to="/posts" className="dropdown-item">자유게시판</Link>
            </div>
          </div>
          {user && user.isAdmin && (
            <div className="nav-item">
              <Link to="/notices/create" className="nav-link">공지사항 작성</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

// App 컴포넌트
const App = () => {
  const { user, logout } = useAuth(); // 로그인 상태와 로그아웃 함수 가져오기

  return (
    <div>
      <div className="logininfo">
        {user ? (
          <>
            <Link to="/main" className="nav-link">홈</Link>
            <Link to="/login" className="nav-link" onClick={logout}>로그아웃</Link>
          </>
        ) : (
          <>
            <Link to="/main" className="nav-link">홈</Link>
            <Link to="/login" className="nav-link">로그인</Link>
            <Link to="/join" className="nav-link">회원가입</Link>
          </>
        )}
      </div>

      <Navigation />

      <Routes>
        <Route path="/" element={<Main />} />
        <Route path= "/main" element={<Main />} />
        <Route path="/login" element={<Login />} />
        <Route path="/join" element={<Join />} />
        <Route path="/classification" element={<ImageUploader />} />
        <Route path="/quiz" element={<Quiz />} />

        <Route path="/board/create" element={<CreatePost />} />
        <Route path="/posts/:postId" element={<PostDetail />} />
        <Route path="/posts" element={<PostList />} />

        <Route path="/notices" element={<NoticeList />} />
        <Route path="/notices/create" element={<NoticeCreate />} />
        <Route path="/notices/:id" element={<NoticeDetail />} />
      </Routes>
    </div>
  );
};

// 전체 애플리케이션 컴포넌트
const AppWrapper = () => (
  <BrowserRouter>
    <AuthProvider>
      <App />
    </AuthProvider>
  </BrowserRouter>
);

export default AppWrapper;
