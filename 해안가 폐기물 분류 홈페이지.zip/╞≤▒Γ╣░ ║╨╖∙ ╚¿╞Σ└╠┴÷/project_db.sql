-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        11.3.2-MariaDB - mariadb.org binary distribution
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  12.7.0.6850
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- project_db 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `project_db` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `project_db`;

-- 테이블 project_db.admin_profile 구조 내보내기
CREATE TABLE IF NOT EXISTS `admin_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `admin_level` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `admin_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.admin_profile:~0 rows (대략적) 내보내기

-- 테이블 project_db.authtoken_token 구조 내보내기
CREATE TABLE IF NOT EXISTS `authtoken_token` (
  `key` char(40) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `key` (`key`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.authtoken_token:~11 rows (대략적) 내보내기
INSERT INTO `authtoken_token` (`key`, `user_id`, `created`) VALUES
	('125abc23ccd9d708c2766aeb585d9863b08d9f82', 11, '2024-08-17 08:30:30'),
	('4a73b002c037404f8da298d83267e268ac6a9363', 17, '2024-08-18 15:44:26'),
	('66b2c31fd6550ecc5e36e2475756cd2df791728b', 21, '2024-08-21 01:30:40'),
	('6a0b02ae906db521b4e14307840861cceea75dac', 18, '2024-08-20 11:13:12'),
	('7773a43fdcce0c958c51f618ff13539459948c55', 10, '2024-08-17 08:08:21'),
	('93e310c7b42ebe23c447666f50a6502381136480', 13, '2024-08-18 05:00:08'),
	('b1a31136973445627dba76aaad69b29c35b5bdc7', 12, '2024-08-18 04:48:14'),
	('b4b2659200146c984ff3d41148b04fe77f2cf44c', 20, '2024-08-20 10:39:51'),
	('cda0b13ebd6242593cdab3a9c0df53d5f183b53f', 19, '2024-08-19 02:30:59'),
	('d0277beff963479b22772783da77b3c51cc45ba8', 9, '2024-08-17 08:03:54'),
	('f984651ca689d4e3ff12608b53d276e62a6e6073', 8, '2024-08-17 07:28:07');

-- 테이블 project_db.auth_group 구조 내보내기
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.auth_group:~0 rows (대략적) 내보내기

-- 테이블 project_db.auth_group_permissions 구조 내보내기
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.auth_group_permissions:~0 rows (대략적) 내보내기

-- 테이블 project_db.auth_permission 구조 내보내기
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.auth_permission:~24 rows (대략적) 내보내기
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
	(1, 'Can add log entry', 1, 'add_logentry'),
	(2, 'Can change log entry', 1, 'change_logentry'),
	(3, 'Can delete log entry', 1, 'delete_logentry'),
	(4, 'Can view log entry', 1, 'view_logentry'),
	(5, 'Can add permission', 2, 'add_permission'),
	(6, 'Can change permission', 2, 'change_permission'),
	(7, 'Can delete permission', 2, 'delete_permission'),
	(8, 'Can view permission', 2, 'view_permission'),
	(9, 'Can add group', 3, 'add_group'),
	(10, 'Can change group', 3, 'change_group'),
	(11, 'Can delete group', 3, 'delete_group'),
	(12, 'Can view group', 3, 'view_group'),
	(13, 'Can add user', 4, 'add_user'),
	(14, 'Can change user', 4, 'change_user'),
	(15, 'Can delete user', 4, 'delete_user'),
	(16, 'Can view user', 4, 'view_user'),
	(17, 'Can add content type', 5, 'add_contenttype'),
	(18, 'Can change content type', 5, 'change_contenttype'),
	(19, 'Can delete content type', 5, 'delete_contenttype'),
	(20, 'Can view content type', 5, 'view_contenttype'),
	(21, 'Can add session', 6, 'add_session'),
	(22, 'Can change session', 6, 'change_session'),
	(23, 'Can delete session', 6, 'delete_session'),
	(24, 'Can view session', 6, 'view_session');

-- 테이블 project_db.auth_user 구조 내보내기
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(254) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.auth_user:~11 rows (대략적) 내보내기
INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
	(8, 'pbkdf2_sha256$720000$hoX5UEy1xFG803BKlnrKcS$lnatk03CPuk7vi+z3UmcY7B9SRdLGUr8+F6crGUsVVc=', NULL, 0, '1111', '', '', '1111@gmail.com', 0, 1, '2024-08-17 07:28:06.862731'),
	(9, 'pbkdf2_sha256$720000$dFdkNaTLYd0REY3eliE9Uf$obnuNZhJq9E7CjhCIodOg+vREob3PNHSrGKj1eOvdRQ=', NULL, 0, '2222', '', '', '2222@gmail.com', 0, 1, '2024-08-17 08:03:54.126732'),
	(10, 'pbkdf2_sha256$720000$u1TXgdirNrgDGkRDDqEREW$+dUDDib3RjGyG+tXwoP2uJfEBpQ4kZAZj6o/wiseRx0=', NULL, 0, '3333', '', '', '3333@gmail.com', 0, 1, '2024-08-17 08:08:21.045979'),
	(11, 'pbkdf2_sha256$720000$8LL4pki7W70kfhj9DwezaC$JXIZiGE/okHwOrVdofmRek7vCCh08S5ufyhdqWbeGNs=', NULL, 0, '5555', '', '', '5555@gmail.com', 0, 1, '2024-08-17 08:30:30.698692'),
	(12, 'pbkdf2_sha256$720000$UTGTpusRfqSJoiCfjAwz3M$C8WTPfGyjpkHyVt1xBe+pJ/d/fHa7JQ6d8nCHUqkYag=', NULL, 0, '6666', '', '', '6666@gmail.com', 0, 1, '2024-08-18 04:48:13.691345'),
	(13, 'pbkdf2_sha256$720000$c0FQzudWvgxMFIcdL2Kld8$z+AczeRgEwe9SBsUNxL6EJDv5JLejHUHJUwvEhmZ/Lk=', NULL, 0, '7777', '', '', '7777@gmail.com', 0, 1, '2024-08-18 05:00:08.130007'),
	(17, 'pbkdf2_sha256$720000$Uuv4EBGz9Bxovf9hnmo5fp$lDPxNNfk1KZFuH/5jn11b1EVpXaDVUOO0meGZK7w1F8=', NULL, 0, '8888', '', '', '8888@gmail.com', 0, 1, '2024-08-18 15:44:26.618987'),
	(18, 'pbkdf2_sha256$720000$iJc5p6pk9q1juTNtEjmmY1$yq8LQZQh5Yk25g+X/3EunsBHjtsBTzcTUZyaI9mkQfU=', '2024-08-18 15:45:28.157208', 1, 'admin', '', '', 'hister0708@naver.com', 1, 1, '2024-08-18 15:44:58.476990'),
	(19, 'pbkdf2_sha256$720000$ZyUfKVwZk4kBaAQA42ChDi$JfIGWv2httWs5EOurGE0I29ufvlYp9P9B78C2qW+kQE=', NULL, 0, '4444', '', '', '4444@gmail.com', 0, 1, '2024-08-19 02:30:59.441155'),
	(20, 'pbkdf2_sha256$720000$fISQfTf84hJUlPi9VLBP9J$v/rHur2TzaEqimVTCCB1WVGMsl0gQhJs41KjgreMpW0=', NULL, 0, '9999', '', '', '9999@gmail.com', 0, 1, '2024-08-20 10:39:51.383215'),
	(21, 'pbkdf2_sha256$720000$chHpJazvbe0tleYB49KjqD$GZrrQdocY7ZmHlLBSzuc5PrQFhRsBrw4SvNAmooIuX8=', NULL, 0, '영선', '', '', 'dudtjs@gmail.com', 0, 1, '2024-08-21 01:30:39.892516');

-- 테이블 project_db.auth_user_groups 구조 내보내기
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.auth_user_groups:~0 rows (대략적) 내보내기

-- 테이블 project_db.auth_user_user_permissions 구조 내보내기
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.auth_user_user_permissions:~0 rows (대략적) 내보내기

-- 테이블 project_db.comment 구조 내보내기
CREATE TABLE IF NOT EXISTS `comment` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comment_content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_at` datetime(6) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `FK_comment_posts` (`post_id`),
  CONSTRAINT `FK_comment_posts` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.comment:~2 rows (대략적) 내보내기
INSERT INTO `comment` (`comment_id`, `comment_content`, `create_at`, `post_id`, `update_at`, `user_id`) VALUES
	(1, 'ㅅㄷㄴㅅ', '2024-08-20 17:58:19.160945', NULL, '2024-08-20 17:58:19.160945', '2222'),
	(7, 'ㄱㄱㄱ', '2024-08-21 17:28:41.895001', 3, '2024-08-21 17:28:44.006695', '2222');

-- 테이블 project_db.django_admin_log 구조 내보내기
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.django_admin_log:~0 rows (대략적) 내보내기

-- 테이블 project_db.django_content_type 구조 내보내기
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.django_content_type:~6 rows (대략적) 내보내기
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
	(1, 'admin', 'logentry'),
	(3, 'auth', 'group'),
	(2, 'auth', 'permission'),
	(4, 'auth', 'user'),
	(5, 'contenttypes', 'contenttype'),
	(6, 'sessions', 'session');

-- 테이블 project_db.django_migrations 구조 내보내기
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.django_migrations:~18 rows (대략적) 내보내기
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
	(1, 'contenttypes', '0001_initial', '2024-08-16 13:44:37.766593'),
	(2, 'auth', '0001_initial', '2024-08-16 13:44:38.267702'),
	(3, 'admin', '0001_initial', '2024-08-16 13:44:38.373534'),
	(4, 'admin', '0002_logentry_remove_auto_add', '2024-08-16 13:44:38.381157'),
	(5, 'admin', '0003_logentry_add_action_flag_choices', '2024-08-16 13:44:38.388573'),
	(6, 'contenttypes', '0002_remove_content_type_name', '2024-08-16 13:44:38.460154'),
	(7, 'auth', '0002_alter_permission_name_max_length', '2024-08-16 13:44:38.495591'),
	(8, 'auth', '0003_alter_user_email_max_length', '2024-08-16 13:44:38.528155'),
	(9, 'auth', '0004_alter_user_username_opts', '2024-08-16 13:44:38.528155'),
	(10, 'auth', '0005_alter_user_last_login_null', '2024-08-16 13:44:38.580651'),
	(11, 'auth', '0006_require_contenttypes_0002', '2024-08-16 13:44:38.584965'),
	(12, 'auth', '0007_alter_validators_add_error_messages', '2024-08-16 13:44:38.588327'),
	(13, 'auth', '0008_alter_user_username_max_length', '2024-08-16 13:44:38.616755'),
	(14, 'auth', '0009_alter_user_last_name_max_length', '2024-08-16 13:44:38.650818'),
	(15, 'auth', '0010_alter_group_name_max_length', '2024-08-16 13:44:38.675011'),
	(16, 'auth', '0011_update_proxy_permissions', '2024-08-16 13:44:38.683106'),
	(17, 'auth', '0012_alter_user_first_name_max_length', '2024-08-16 13:44:38.714712'),
	(18, 'sessions', '0001_initial', '2024-08-16 13:44:38.771897');

-- 테이블 project_db.django_session 구조 내보내기
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.django_session:~1 rows (대략적) 내보내기
INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
	('js6ji0qfda0u1biiuh54ucj38tnrcj7c', '.eJxVjDsOwjAQBe_iGll21nbWlPQ5Q7Reb0gA2VI-FeLuJFIKaGfmvbfqaVvHfltk7qesrsqiuvzCRPyUcpj8oHKvmmtZ5ynpI9GnXXRXs7xuZ_t3MNIy7mugFiwby5CJA2AToAmeUSjYYUcC1nvANtJgkL1JKGCMGzBClOSc-nwB_V03og:1sfi5w:1Gk_TQKd3BNbalFqsgtlQnzERLgj0KOeS9ryNtgeZZk', '2024-09-01 15:45:28.164602');

-- 테이블 project_db.image_classification 구조 내보내기
CREATE TABLE IF NOT EXISTS `image_classification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `model_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'default_model_path',
  `prediction` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `points` int(11) DEFAULT 0,
  `user_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.image_classification:~20 rows (대략적) 내보내기
INSERT INTO `image_classification` (`id`, `image`, `model_number`, `prediction`, `uploaded_at`, `points`, `user_id`) VALUES
	(1, 'images/KakaoTalk_20240821_111747547_02_O5vRFRG.jpg', '2_glass.keras', 'Unknown', '2024-08-21 03:41:16', 0, NULL),
	(2, 'images/KakaoTalk_20240821_111747547_02_43bFGMw.jpg', '2_glass.keras', 'Unknown', '2024-08-21 03:42:36', 0, NULL),
	(3, 'images/KakaoTalk_20240821_111747547_02_IeDTdLY.jpg', '2_glass.keras', 'Unknown', '2024-08-21 03:46:17', 0, NULL),
	(4, 'images/KakaoTalk_20240821_111747547_02_2MWVRdf.jpg', '2_glass.keras', 'Unknown', '2024-08-21 03:48:11', 0, NULL),
	(5, 'images/KakaoTalk_20240821_111747547_02_RoKcRzZ.jpg', '2_glass.keras', 'Unknown', '2024-08-21 03:51:53', 0, NULL),
	(6, 'images/KakaoTalk_20240821_111747547_02_hTirpx5.jpg', '2_glass.keras', 'Unknown', '2024-08-21 03:55:45', 0, NULL),
	(7, 'images/KakaoTalk_20240821_111747547_07.jpg', '3_can.keras', 'Unknown', '2024-08-21 05:17:35', 10, NULL),
	(8, 'images/KakaoTalk_20240821_111747547_02_SxDK4ZD.jpg', '2_glass.keras', 'Unknown', '2024-08-21 05:42:35', 10, '18'),
	(9, 'images/KakaoTalk_20240821_111747547_07_qDwzfWP.jpg', '3_can.keras', 'Unknown', '2024-08-21 05:46:19', 10, '11'),
	(10, 'images/KakaoTalk_20240821_111747547_07_1FEuMmv.jpg', '3_can.keras', 'Unknown', '2024-08-21 06:41:26', 10, '9'),
	(11, 'images/KakaoTalk_20240821_111747547_07_LfnVHdE.jpg', '3_can.keras', 'Unknown', '2024-08-21 07:40:25', 10, '9'),
	(12, 'images/KakaoTalk_20240821_111747547_02_7tWqC0W.jpg', '2_glass.keras', 'Unknown', '2024-08-21 08:07:58', 10, '9'),
	(13, 'images/KakaoTalk_20240821_111747547_01.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 08:36:22', 10, '17'),
	(14, 'images/KakaoTalk_20240821_111747547_01_jT2HTGc.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 08:38:24', 10, '17'),
	(15, 'images/KakaoTalk_20240821_111747547_01_hmpBgxB.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 09:29:25', 10, '20'),
	(16, 'images/KakaoTalk_20240821_111747547_01_umkQdzg.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 09:53:43', 10, '20'),
	(17, 'images/KakaoTalk_20240821_111747547_01_ZfdW952.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 09:54:44', 10, '20'),
	(18, 'images/KakaoTalk_20240821_111747547_01_LcX8Dvu.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 09:55:19', 10, '20'),
	(19, 'images/KakaoTalk_20240821_111747547_01_SzS1pQa.jpg', '1_haeyang.keras', 'Unknown', '2024-08-21 10:02:04', 10, '20'),
	(20, 'images/KakaoTalk_20240821_111747547_02_Tgo1yYM.jpg', '2_glass.keras', 'Unknown', '2024-08-21 10:16:07', 10, '20'),
	(21, 'images/KakaoTalk_20240821_111747547_02_0aavz8P.jpg', '2_glass.keras', 'Unknown', '2024-08-21 11:17:32', 10, '13');

-- 테이블 project_db.logs 구조 내보내기
CREATE TABLE IF NOT EXISTS `logs` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `activity` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.logs:~0 rows (대략적) 내보내기

-- 테이블 project_db.notices 구조 내보내기
CREATE TABLE IF NOT EXISTS `notices` (
  `notice_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `is_important` bit(1) DEFAULT NULL,
  `notice_content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `notice_title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.notices:~5 rows (대략적) 내보내기
INSERT INTO `notices` (`notice_id`, `create_at`, `is_important`, `notice_content`, `notice_title`, `update_at`, `user_id`) VALUES
	(1, '2024-08-21 09:33:51.544618', b'0', '공지사항테스트입니다', '공지사항테스트', '2024-08-21 09:33:51.544618', 'admin'),
	(2, '2024-08-21 09:34:06.876619', b'1', '중요공지테스트입니다', '중요공지테스트', '2024-08-21 09:34:06.876619', 'admin'),
	(3, '2024-08-21 09:42:37.083439', b'0', '수정', 'ㅅㄷㄴㅅ', '2024-08-21 09:44:29.050947', '2222'),
	(4, '2024-08-21 10:31:54.741616', b'0', 'ㅅㄷㄴㅅ', 'ㅅㄷㄴㅅ', '2024-08-21 10:31:54.741616', '영선'),
	(5, '2024-08-21 18:13:05.165400', b'1', 'ㅅㄷㄴㅅ', '중요테스트', '2024-08-21 18:13:05.165400', '5555');

-- 테이블 project_db.posts 구조 내보내기
CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `post_content` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `post_title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.posts:~6 rows (대략적) 내보내기
INSERT INTO `posts` (`post_id`, `create_at`, `post_content`, `post_title`, `update_at`, `user_id`) VALUES
	(1, '2024-08-20 17:52:11.831999', 'test', 'test', '2024-08-20 17:52:11.831999', '1111'),
	(3, '2024-08-20 19:19:02.834144', 'ㅅㄷㄴㅅ2', 'ㅅㄷㄴㅅ2', '2024-08-20 19:19:02.834144', '2222'),
	(5, '2024-08-20 20:13:33.014611', 'admin', 'admin', '2024-08-20 20:13:33.014611', 'admin'),
	(6, '2024-08-21 09:42:57.453841', 'ㄷㄴㅅ', 'ㅅㄴㄷㅅ', '2024-08-21 09:42:57.453841', '2222'),
	(7, '2024-08-21 10:30:58.395821', '쌉가능', '한글', '2024-08-21 10:30:58.395821', '영선'),
	(8, '2024-08-21 10:31:24.858603', 'ㅅㄷㄴㅅ', 'ㅅㄷㄴㅅ', '2024-08-21 10:31:24.858603', '영선');

-- 테이블 project_db.quiz 구조 내보내기
CREATE TABLE IF NOT EXISTS `quiz` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `answer` char(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.quiz:~50 rows (대략적) 내보내기
INSERT INTO `quiz` (`num`, `question`, `answer`) VALUES
	(1, '지구 온난화는 지구의 평균 기온이 상승하는 현상이다.', 'O'),
	(2, '플라스틱은 자연에서 쉽게 분해된다.', 'X'),
	(3, '대기 오염은 인간의 건강에 해롭지 않다.', 'X'),
	(4, '나무를 많이 심으면 이산화탄소를 줄일 수 있다.', 'O'),
	(5, '해양 오염의 주 원인은 플라스틱 쓰레기다.', 'O'),
	(6, '산림 파괴는 동물의 서식지를 위협한다.', 'O'),
	(7, '미세먼지는 눈에 보이지 않는 작은 먼지다.', 'O'),
	(8, '전기를 아끼면 탄소 배출량을 줄일 수 없다.', 'X'),
	(9, '재활용을 통해 자원을 절약할 수 있다.', 'O'),
	(10, '해수면 상승은 기후 변화의 영향이다. ', 'O'),
	(11, '재생 에너지는 환경에 해롭다.', 'X'),
	(12, '물은 지구에서 무한히 사용할 수 있는 자원이다.', 'X'),
	(13, '화석 연료는 지구 온난화의 원인 중 하나다.', 'O'),
	(14, '공장들은 대기 오염의 주요 원인 중 하나다.', 'O'),
	(15, '일회용품 사용을 줄이면 환경 보호에 도움이 된다.', 'O'),
	(16, '산림은 지구의 산소를 생산하는 주요 장소이다.', 'O'),
	(17, '해양 생태계는 인간 활동에 의해 위협받고 있다.', 'O'),
	(18, '자동차 배기가스는 대기 오염의 원인이 아니다.', 'X'),
	(19, '지구의 자원은 무한하다.', 'X'),
	(20, '전자 폐기물은 재활용이 불가능하다.', 'X'),
	(21, '오존층은 자외선을 차단하는 역할을 한다.', 'O'),
	(22, '플라스틱 빨대는 환경에 해롭지 않다.', 'X'),
	(23, '에어컨 사용이 많을수록 전기 소비가 늘어난다. ', 'O'),
	(24, '물을 아껴 쓰는 것이 환경 보호에 도움이 된다.', 'O'),
	(25, '대기 오염은 오직 도시에서만 발생한다.', 'X'),
	(26, '멸종 위기 종의 보호는 생물 다양성을 지키는 데 중요하다.', 'O'),
	(27, '기후 변화는 자연적인 현상만으로 발생한다.', 'X'),
	(28, '유전자 변형 생물은 환경에 안전하다.', 'X'),
	(29, '야생 동물의 서식지를 보호하는 것은 환경 보호의 일환이다.', 'O'),
	(30, '인간 활동은 지구의 기온에 영향을 미칠 수 없다.', 'X'),
	(31, '태양광 에너지는 재생 가능한 에너지이다.', 'O'),
	(32, '플라스틱은 해양 생물에게 해롭다.', 'O'),
	(33, '물 부족 문제는 일부 국가에서만 발생한다.', 'X'),
	(34, '에너지를 절약하면 지구 환경을 보호할 수 있다.', 'O'),
	(35, '산성비는 식물을 해칠 수 있다.', 'O'),
	(36, '기후 변화는 농업에 영향을 미치지 않는다.', 'X'),
	(37, '재활용은 쓰레기를 줄이는 방법 중 하나이다. ', 'O'),
	(38, '지구의 온도 상승은 극지방의 빙하를 녹게 한다.', 'O'),
	(39, '가축 사육은 온실가스 배출과 관련이 없다.', 'X'),
	(40, '화학 물질은 토양을 오염시킬 수 있다.', 'O'),
	(41, '비닐봉투는 자연에서 쉽게 분해된다.', 'X'),
	(42, '대중교통을 이용하면 탄소 배출을 줄일 수 있다.', 'O'),
	(43, '해양 산성화는 산소 농도를 높인다.', 'X'),
	(44, '전기를 아끼는 것은 환경 보호에 도움이 된다.', 'O'),
	(45, '숲은 이산화탄소를 흡수하는 역할을 한다. ', 'O'),
	(46, '과도한 어업은 해양 자원 고갈을 초래한다.', 'O'),
	(47, '일회용 플라스틱 사용이 늘어나면 해양 오염도 증가한다.', 'O'),
	(48, '재생 가능 에너지는 환경을 보호하는 데 중요한 역할을 한다.', 'O'),
	(49, '기후 변화는 단지 과학자들의 상상이다. ', 'X'),
	(50, '지구를 보호하기 위해 우리는 에너지를 절약해야 한다.', 'O');

-- 테이블 project_db.quizzes 구조 내보내기
CREATE TABLE IF NOT EXISTS `quizzes` (
  `quiz_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `quiz_data` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `quiz_result` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`quiz_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.quizzes:~0 rows (대략적) 내보내기

-- 테이블 project_db.spring_integration 구조 내보내기
CREATE TABLE IF NOT EXISTS `spring_integration` (
  `integration_id` bigint(20) NOT NULL DEFAULT 0,
  `user_id` bigint(20) DEFAULT NULL,
  `spring_url` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`integration_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.spring_integration:~0 rows (대략적) 내보내기

-- 테이블 project_db.userquizscore 구조 내보내기
CREATE TABLE IF NOT EXISTS `userquizscore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT curdate(),
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`quiz_id`),
  KEY `quiz_id` (`quiz_id`),
  CONSTRAINT `userquizscore_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userquizscore_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`num`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- 테이블 데이터 project_db.userquizscore:~4 rows (대략적) 내보내기
INSERT INTO `userquizscore` (`id`, `user_id`, `quiz_id`, `date`, `score`) VALUES
	(1, 18, 22, '2024-08-19', 1),
	(2, 10, 22, '2024-08-19', 1),
	(3, 19, 22, '2024-08-19', 1),
	(4, 13, 22, '2024-08-19', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
