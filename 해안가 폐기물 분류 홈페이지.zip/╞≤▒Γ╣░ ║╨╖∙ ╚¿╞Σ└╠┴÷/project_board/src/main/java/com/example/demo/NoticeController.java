package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/notices")
public class NoticeController {

    @Autowired
    private NoticeRepository noticeRepository;

    // 모든 공지사항 조회
    @GetMapping
    public ResponseEntity<List<Notice>> getAllNotices() {
        try {
            List<Notice> notices = noticeRepository.findAll();

            if (notices.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notices, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 중요 공지사항만 조회
    @GetMapping("/important")
    public ResponseEntity<List<Notice>> getImportantNotices() {
        try {
            List<Notice> notices = noticeRepository.findByIsImportantTrue();

            if (notices.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notices, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 특정 공지사항 조회
    @GetMapping("/{id}")
    public ResponseEntity<Notice> getNoticeById(@PathVariable Long id) {
        Optional<Notice> noticeData = noticeRepository.findById(id);

        if (noticeData.isPresent()) {
            return new ResponseEntity<>(noticeData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // 공지사항 생성
    @PostMapping
    public ResponseEntity<Notice> createNotice(@RequestBody Notice notice) {
        try {
            Notice newNotice = noticeRepository.save(notice); // 직접 save 호출
            return new ResponseEntity<>(newNotice, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 공지사항 수정
    @PutMapping("/{id}")
    public ResponseEntity<Notice> updateNotice(@PathVariable Long id, @RequestBody Notice noticeDetails) {
        Optional<Notice> noticeData = noticeRepository.findById(id);

        if (noticeData.isPresent()) {
            Notice notice = noticeData.get();
            notice.setNoticeTitle(noticeDetails.getNoticeTitle());
            notice.setNoticeContent(noticeDetails.getNoticeContent());
            notice.setIsImportant(noticeDetails.getIsImportant());
            // userId는 클라이언트가 제공하는 것이 아니라, 서버 측에서 현재 사용자 정보를 설정해야 할 수도 있음
            // notice.setUserId(noticeDetails.getUserId()); 
            Notice updatedNotice = noticeRepository.save(notice);
            return new ResponseEntity<>(updatedNotice, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // 공지사항 삭제
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteNotice(@PathVariable Long id) {
        try {
            noticeRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @Autowired
    private NoticeService noticeService;

 // 최신 5개의 공지사항 조회
    @GetMapping("/latest")
    public ResponseEntity<List<Notice>> getLatestNotices() {
        List<Notice> latestNotices = noticeService.getLatestNotices(5);
        return latestNotices.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(latestNotices, HttpStatus.OK);
    }
}
