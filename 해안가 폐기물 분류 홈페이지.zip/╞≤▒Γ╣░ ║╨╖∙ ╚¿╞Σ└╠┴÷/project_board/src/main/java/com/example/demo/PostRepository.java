package com.example.demo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<Post, Long> {
    // 제목으로 검색
    List<Post> findByPostTitleContaining(String postTitle);
    
    // 작성자(userId)로 검색
    List<Post> findByUserId(String userId);

    // 제목과 작성자(userId)로 검색
    List<Post> findByPostTitleContainingAndUserId(String postTitle, String userId);
    
    List<Post> findTop5ByOrderByCreateAtDesc();
}
