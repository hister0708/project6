package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Service
public class NoticeService {

    @Autowired
    private NoticeRepository noticeRepository;

    public List<Notice> getLatestNotices(int limit) {
        return noticeRepository.findTop5ByOrderByCreateAtDesc(PageRequest.of(0, limit)).getContent();
    }
}
