package com.example.demo;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "posts")
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long postId;

    @Column(name = "user_id")
    private String userId; // 타입을 String으로 변경

    @Column(name = "post_title")
    private String postTitle;

    @Column(name = "post_content")
    private String postContent;

    @Column(name = "create_at")
    private LocalDateTime createAt;

    @Column(name = "update_at")
    private LocalDateTime updateAt;
    
    // 기본 생성자
    public Post() {}

    // 매개변수 생성자
    public Post(String userId, String postTitle, String postContent) { // String으로 변경
        this.userId = userId;
        this.postTitle = postTitle;
        this.postContent = postContent;
    }

    // Getter and Setter
    public long getPostId() {
        return postId;
    }

    public void setPostId(long postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId; // 반환 타입도 String으로 변경
    }

    public void setUserId(String userId) { // 매개변수 타입도 String으로 변경
        this.userId = userId;
    }

    public String getPostTitle() {
        return postTitle;
    }

    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }

    public String getPostContent() {
        return postContent;
    }

    public void setPostContent(String postContent) {
        this.postContent = postContent;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    public LocalDateTime getUpdateAt() {
        return updateAt;
    }

    // @PrePersist: 엔티티가 처음 저장되기 전에 호출
    @PrePersist
    protected void onCreate() {
        this.createAt = LocalDateTime.now();
        this.updateAt = LocalDateTime.now();
    }

    // @PreUpdate: 엔티티가 업데이트되기 전에 호출
    @PreUpdate
    protected void onUpdate() {
        this.updateAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "Post [postId=" + postId + ", userId=" + userId + ", postTitle=" + postTitle + ", postContent="
                + postContent + ", createAt=" + createAt + ", updateAt=" + updateAt + "]";
    }
}
