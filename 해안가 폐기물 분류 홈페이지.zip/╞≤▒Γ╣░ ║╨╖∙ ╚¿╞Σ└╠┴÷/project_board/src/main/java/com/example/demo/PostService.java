package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private CommentService commentService;

    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    public List<Post> searchPosts(String title, String userId) { // userId 타입을 String으로 변경
        if (title != null && userId != null) {
            return postRepository.findByPostTitleContainingAndUserId(title, userId);
        } else if (title != null) {
            return postRepository.findByPostTitleContaining(title);
        } else if (userId != null) {
            return postRepository.findByUserId(userId);
        } else {
            return postRepository.findAll();
        }
    }

    public Post createPost(Post post) {
        return postRepository.save(post);
    }

    public Optional<Post> getPostById(Long postId) {
        return postRepository.findById(postId);
    }

    public Post updatePost(Long postId, Post postDetails) {
        Optional<Post> postData = postRepository.findById(postId);

        if (postData.isPresent()) {
            Post post = postData.get();
            post.setUserId(postDetails.getUserId()); // userId가 String으로 변경됨
            post.setPostTitle(postDetails.getPostTitle());
            post.setPostContent(postDetails.getPostContent());
            return postRepository.save(post);
        } else {
            return null;
        }
    }

    @Transactional
    public void deletePost(Long postId) {
        // 댓글 삭제
        commentService.deleteCommentsByPostId(postId);

        // 게시글 삭제
        postRepository.deleteById(postId);
    }
    
    public List<Post> getLatestPosts() {
        return postRepository.findTop5ByOrderByCreateAtDesc();
    }
}
