from django.contrib import admin
from .models import User
# Register your models here.


admin.site.register(User)

from .models import AdminProfile

@admin.register(AdminProfile)
class AdminProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'admin_level')
    search_fields = ('user__username',)