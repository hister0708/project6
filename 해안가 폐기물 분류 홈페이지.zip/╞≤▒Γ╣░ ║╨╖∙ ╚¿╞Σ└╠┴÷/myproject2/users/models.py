from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone


# Create your models here.

class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not username:
            raise ValueError('The Username field must be set')
        if not email:
            raise ValueError('The Email field must be set')

        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(username, email, password, **extra_fields)

    def get_by_natural_key(self, username):
        return self.get(username=username)


class User(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128)
    first_name = models.CharField(max_length=30, blank=True, default='')  # 기본값을 추가
    last_name = models.CharField(max_length=30, blank=True, default='')  # 기본값을 추가
    last_login = models.DateTimeField(null=True, blank=True)
    is_staff = models.BooleanField(default=False)  # 관리자 여부 필드 추가
    is_active = models.BooleanField(default=True)  # 사용자의 활성 여부 필드 추가
    is_superuser = models.BooleanField(default=False)  # 기본값을 False로 설정
    date_joined = models.DateTimeField(default=timezone.now)  # 가입일 필드 추가

    objects = UserManager()  # Custom UserManager를 사용하도록 설정

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    def __str__(self):
        return self.username

    class Meta:
        db_table = 'auth_user'
        managed = True

# admin만 관리하는 테이블 추가
from django.conf import settings
from django.contrib.auth import get_user_model

User = get_user_model()  # 현재 설정된 사용자 모델을 가져옵니다

class AdminProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    admin_level = models.IntegerField(default=1)
    # 다른 필드들...

    def __str__(self):
        return f'{self.user.username} - Admin Profile'

    class Meta:
        db_table = 'admin_profile'  # 데이터베이스에 생성한 테이블 이름을 지정