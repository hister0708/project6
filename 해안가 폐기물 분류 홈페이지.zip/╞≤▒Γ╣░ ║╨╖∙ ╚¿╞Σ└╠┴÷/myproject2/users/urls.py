from django.urls import path
from .views import RegisterUser, LoginUser, LogoutView
from .views import UserView, CustomObtainAuthToken
from rest_framework.authtoken.views import obtain_auth_token

urlpatterns = [
    path('api/register/', RegisterUser.as_view(), name='register'),  # 사용자 등록 엔드포인트
    path('api/login/', CustomObtainAuthToken.as_view(), name='login'),  # 기본 제공 로그인 엔드포인트
    path('api/logout/', LogoutView.as_view(), name='logout'),
    path('api/user/', UserView.as_view(), name='user'),
]
