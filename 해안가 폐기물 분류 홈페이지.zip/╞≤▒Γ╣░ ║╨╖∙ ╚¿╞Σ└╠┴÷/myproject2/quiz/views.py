from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from datetime import date
from .models import Quiz, UserQuizScore
import random

@api_view(['GET', 'POST'])
def quiz_view(request):
    today = date.today()
    quizzes = list(Quiz.objects.all())

    if not quizzes:
        return Response({'error': '퀴즈 데이터가 없습니다.'})

    random.seed(today.isoformat())
    quiz = random.choice(quizzes)

    if request.method == 'POST':
        user_answer = request.data.get('answer')
        if user_answer == quiz.answer:
            UserQuizScore.objects.update_or_create(
                user=request.user,
                quiz=quiz,
                defaults={'score': 1}
            )
            return Response({'correct': True, 'message': '정답입니다!'})
        else:
            return Response({'correct': False, 'message': '틀렸습니다!'})

    if request.method == 'GET':
        return Response({
            'question': quiz.question,
            'choices': [quiz.answer]  # 예시로 답만 제공
        })

    return Response({'error': 'Method not allowed'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
