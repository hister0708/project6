# quiz/urls.py
from django.urls import path
from .views import quiz_view

urlpatterns = [
    path('api/quiz/', quiz_view, name='quiz_view'),
]
