# quiz/models.py
from django.db import models
from django.conf import settings
class Quiz(models.Model):
    num = models.IntegerField(primary_key=True)
    question = models.CharField(max_length=100)
    answer = models.CharField(max_length=10)

    def __str__(self):
        return self.question

    class Meta:
        db_table = 'quiz'  # 기존 데이터베이스 테이블 이름

class UserQuizScore(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)  # 사용자와 연결
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)  # 푼 문제
    date = models.DateField(auto_now_add=True)  # 문제를 푼 날짜
    score = models.IntegerField(default=0)  # 점수

    class Meta:
        db_table = 'userquizscore'