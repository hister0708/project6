import os
import django
from django.core.exceptions import ImproperlyConfigured
from django.template.loader import get_template
from django.template import TemplateDoesNotExist

# Django settings 초기화
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

try:
    template = get_template('image_classifier/image_list.html')
    print("Template found")
except TemplateDoesNotExist:
    print("Template does not exist")
except ImproperlyConfigured as e:
    print(f"ImproperlyConfigured: {e}")
