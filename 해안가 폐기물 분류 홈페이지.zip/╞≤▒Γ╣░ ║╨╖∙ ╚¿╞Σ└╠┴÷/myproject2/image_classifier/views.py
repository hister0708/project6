from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from .forms import ImageUploadForm
from .models import ImageClassification
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os
import logging
from django.conf import settings

# 로그 설정
logger = logging.getLogger(__name__)

# 클래스 이름을 모델별로 매핑한 딕셔너리
class_names_dict = {
    '1_haeyang.keras': ['로프(2kg)', '어망(5kg)'],
    '2_glass.keras': ['갈색병(0.4kg)', '흰색병(0.4kg)', '녹색병(0.4kg)'],
    '3_can.keras': ['스팸캔(0.05kg)', '통조림캔(0.1kg)'],
}

def load_model_from_request(model_name):
    try:
        model_path = os.path.join(settings.MODEL_DIR, model_name)
        logger.info(f"Loading model from: {model_path}")
        model = load_model(model_path)
        logger.info(f"Model loaded successfully")
        print("모델 패스", model_path)
        return model
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        raise

def predict_image(img_path, model):
    try:
        input_shape = model.input_shape[1:3]  # Assuming model expects 2D input
        img = image.load_img(img_path, target_size=input_shape)  # 모델의 입력 크기로 조정
        img_array = image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = img_array / 255.0  # 이미지 정규화 (0-1 범위로)
        predictions = model.predict(img_array)
        predicted_class = np.argmax(predictions[0])
        class_names = class_names_dict.get(os.path.basename(model.path), [])
        return class_names[predicted_class] if predicted_class < len(class_names) else "Unknown"
    except Exception as e:
        logger.error(f"Error predicting image: {e}")
        raise

@api_view(['GET', 'POST'])
def classify_image(request):
    try:
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            image_file = form.cleaned_data['image']
            model_name = form.cleaned_data['keras_models']

            # 모델 로드
            model = load_model_from_request(model_name)

            # 이미지 저장
            image_path = os.path.join(settings.MEDIA_ROOT, 'uploaded_image.jpg')
            with open(image_path, 'wb+') as destination:
                for chunk in image_file.chunks():
                    destination.write(chunk)

            # 예측 수행
            result = predict_image(image_path, model)

            # 이미지 분류 객체 생성 및 포인트 지급
            image_classification = ImageClassification.objects.create(
                image=image_file,
                model_number=model_name,
                prediction=result,
                points=10,  # 모델을 실행했으므로 10 포인트 지급
                user=request.user  # 로그인한 사용자 정보 저장
            )

            return JsonResponse({
                'result': result,
                'points': image_classification.points,
                'message': 'Points awarded'
            })
        else:
            logger.error(f"Form invalid: {form.errors}")
            return JsonResponse({'error': 'Invalid form data'}, status=400)
    except Exception as e:
        logger.error(f"Error in classify_image view: {e}")
        return JsonResponse({'error': 'Internal server error'}, status=500)
