from django.conf import settings
from django.db import models

class ImageClassification(models.Model):
    image = models.ImageField(upload_to='images/')
    model_number = models.CharField(max_length=255, default='default_model_path')
    prediction = models.CharField(max_length=100, blank=True, null=True)  # 예측 결과를 저장할 필드
    uploaded_at = models.DateTimeField(auto_now_add=True)
    points = models.IntegerField(default=0)  # 사용자에게 지급할 포인트를 저장할 필드
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='image_classifications')

    def __str__(self):
        return f"{self.image.name} - {self.prediction} - Points: {self.points} - User: {self.user.username}"

    class Meta:
        db_table = 'image_classification'
